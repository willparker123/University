void drawPieces(struct board *b, struct display *d);

void drawSquares(struct board *b, struct display *d);

display *drawBoard(struct board *b);
